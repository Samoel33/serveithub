import React from 'react'

function Cables() {
  return (
    <>Cables Product</>
  )
}

export default Cables
