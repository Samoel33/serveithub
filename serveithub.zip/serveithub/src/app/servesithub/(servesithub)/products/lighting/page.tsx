import React from 'react'

function Lighting() {
  return (
    <>Lighting Product</>
  )
}

export default Lighting
